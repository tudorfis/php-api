-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2014 at 08:10 PM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `k9koordinator`
--

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `civilities`
--

CREATE TABLE IF NOT EXISTS `civilities` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `civilities`
--

INSERT INTO `civilities` (`id`, `v`, `status`) VALUES
(1, 'Mr.', 'active'),
(2, 'Miss', 'active'),
(3, 'Ms.', 'active'),
(4, 'Mrs.', 'active'),
(5, 'Rev.', 'active'),
(6, 'Dr.', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `civility_id` int(11) NOT NULL DEFAULT '1',
  `first_name` varchar(120) DEFAULT NULL,
  `last_name` varchar(120) DEFAULT NULL,
  `second_owner` varchar(120) DEFAULT NULL,
  `contact_phone` varchar(120) DEFAULT NULL,
  `contact_cell` varchar(120) DEFAULT NULL,
  `emergency_name` varchar(120) DEFAULT NULL,
  `emergency_cell` varchar(120) DEFAULT NULL,
  `emergency_phone` varchar(120) DEFAULT NULL,
  `address_street` varchar(255) DEFAULT NULL,
  `address_city_id` int(11) DEFAULT NULL,
  `address_state_id` int(11) DEFAULT NULL,
  `address_zip_id` int(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `status` enum('new','refuse','vip') NOT NULL DEFAULT 'new',
  PRIMARY KEY (`id`),
  KEY `civility_id` (`civility_id`),
  KEY `address_city_id` (`address_city_id`),
  KEY `address_state_id` (`address_state_id`),
  KEY `address_zip_id` (`address_zip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pet`
--

CREATE TABLE IF NOT EXISTS `pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pet_name` varchar(255) DEFAULT NULL,
  `pet_weight` int(11) DEFAULT NULL,
  `pet_color_id` int(11) DEFAULT NULL,
  `pet_size_id` int(11) DEFAULT NULL,
  `pet_sex_id` int(11) DEFAULT NULL,
  `pet_breed_id` int(11) DEFAULT NULL,
  `pet_type_id` int(11) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `pet_color_id` (`pet_color_id`),
  KEY `pet_size_id` (`pet_size_id`),
  KEY `pet_sex_id` (`pet_sex_id`),
  KEY `pet_breed_id` (`pet_breed_id`),
  KEY `pet_type_id` (`pet_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pet_breed`
--

CREATE TABLE IF NOT EXISTS `pet_breed` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pet_color`
--

CREATE TABLE IF NOT EXISTS `pet_color` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pet_reservations`
--

CREATE TABLE IF NOT EXISTS `pet_reservations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pet_id` int(11) NOT NULL,
  `r_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pet_id` (`pet_id`),
  KEY `r_id` (`r_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pet_sex`
--

CREATE TABLE IF NOT EXISTS `pet_sex` (
  `id` int(11) NOT NULL,
  `v` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pet_size`
--

CREATE TABLE IF NOT EXISTS `pet_size` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `pet_type`
--

CREATE TABLE IF NOT EXISTS `pet_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `r_boarding`
--

CREATE TABLE IF NOT EXISTS `r_boarding` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_in` date DEFAULT NULL,
  `time_in` time DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `r_daycare`
--

CREATE TABLE IF NOT EXISTS `r_daycare` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_in` date DEFAULT NULL,
  `time_in` time DEFAULT NULL,
  `date_out` date DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `r_grooms`
--

CREATE TABLE IF NOT EXISTS `r_grooms` (
  `id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `time_im` time DEFAULT NULL,
  `promissed` varchar(255) DEFAULT NULL,
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `r_training`
--

CREATE TABLE IF NOT EXISTS `r_training` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `training_class_name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v` varchar(255) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `zips`
--

CREATE TABLE IF NOT EXISTS `zips` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `v` int(11) NOT NULL,
  `status` enum('active','inactive','deleted') NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_ibfk_1` FOREIGN KEY (`civility_id`) REFERENCES `civilities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `clients_ibfk_2` FOREIGN KEY (`address_city_id`) REFERENCES `cities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `clients_ibfk_3` FOREIGN KEY (`address_state_id`) REFERENCES `states` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `clients_ibfk_4` FOREIGN KEY (`address_zip_id`) REFERENCES `zips` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pet`
--
ALTER TABLE `pet`
  ADD CONSTRAINT `pet_ibfk_1` FOREIGN KEY (`pet_color_id`) REFERENCES `pet_color` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `pet_ibfk_2` FOREIGN KEY (`pet_size_id`) REFERENCES `pet_size` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `pet_ibfk_3` FOREIGN KEY (`pet_sex_id`) REFERENCES `pet_sex` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `pet_ibfk_4` FOREIGN KEY (`pet_breed_id`) REFERENCES `pet_breed` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `pet_ibfk_5` FOREIGN KEY (`pet_type_id`) REFERENCES `pet_type` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `pet_reservations`
--
ALTER TABLE `pet_reservations`
  ADD CONSTRAINT `pet_reservations_ibfk_1` FOREIGN KEY (`pet_id`) REFERENCES `pet` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `r_boarding`
--
ALTER TABLE `r_boarding`
  ADD CONSTRAINT `r_boarding_ibfk_1` FOREIGN KEY (`id`) REFERENCES `pet_reservations` (`r_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `r_daycare`
--
ALTER TABLE `r_daycare`
  ADD CONSTRAINT `r_daycare_ibfk_1` FOREIGN KEY (`id`) REFERENCES `pet_reservations` (`r_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `r_grooms`
--
ALTER TABLE `r_grooms`
  ADD CONSTRAINT `r_grooms_ibfk_1` FOREIGN KEY (`id`) REFERENCES `pet_reservations` (`r_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `r_training`
--
ALTER TABLE `r_training`
  ADD CONSTRAINT `r_training_ibfk_1` FOREIGN KEY (`id`) REFERENCES `pet_reservations` (`r_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
