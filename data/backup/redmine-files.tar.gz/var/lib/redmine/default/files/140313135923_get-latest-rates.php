<?php
    
    // If from app
    if ($fromApp !== true) {
        
        $db["charset"]   = "utf8";
        $db["host"]      = "176.32.230.2";
        $db["username"]  = "cl44-kanoo";
        $db["password"]  = "cocacola123*";
        $db["dbname"]    = "cl44-kanoo";
        
    // If from cronjob    
    } else if ($fromApp === true) {
        
        $config = new Zend_Config_Ini(APPLICATION_PATH.'/configs/application.ini', APPLICATION_ENV);
        $config = (array) $config->toArray();
        $db = $config['resources']['db']['params'];     
    }

    $conn = mysql_connect($db['host'], $db['username'], $db['password']);
    mysql_select_db($db['dbname']);

    // CRON 
    ini_set('user_agent', 'Firefox (WindowsXP) Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.8.1.6) Gecko/20070725 Firefox/2.0.0.6');
    set_time_limit(2160000);
    ini_set('memory_limit', '128M'); 


    function getratefrom($url) 
    {
        //$url="http://www.xe.com".$url;

        //echo $url . "\n";
        $html = file_get_contents($url);
        //echo "\n\n" . $html . "\n\n";

        if( preg_match( "/<h1 class='H2wTR'>([a-z]+)/i", $html, $currency ) ){
            $currency = $currency[1];
        } else {
            return false;
        }

        if( preg_match( '#<div class="currencyheader">.*?</div>\s*(.*?),.*?</div>#msi', $html, $country ) ){
            $country = $country[1];
        } else {
            return false;
        }

        if( preg_match( "#<a href='/currencycharts/\?from=GBP&amp;to=" . $currency . "'.*?>(.*?)</a>#", $html, $rate ) ){
            $rate = $rate[1];
        } else {
            return false;
        }
        echo $country . ' - ' . $currency . ' from GBP: ' . $rate . "<br />\n";

        $strSQL = "select * from rates where c_code = '". $currency ."' and status <> 'deleted';";
        $result = mysql_query($strSQL);

        if( mysql_num_rows( $result ) == 0 ){
            $ins = "INSERT INTO rates SET ";
            $ins .= "c_code ='" . $currency . "',";    
            $ins .= "country = '" . $country . "',";    
            $ins .= "s_rate = '" . $rate . "',";
            $ins .= "b_rate = '" . $rate . "',";
            $ins .= "date_update = '" . date( "Y-m-d H:i:s" ) . "'";
            mysql_query( $ins ) or die( mysql_error() );
        } 

        else {
            $up = "UPDATE rates SET ";
            $up .= "s_rate ='" . $rate . "',";    
            $up .= "b_rate ='" . $rate . "',";    
            $up .= "date_update = '" . date( "Y-m-d H:i:s" ) . "'";
            $up .= " WHERE c_code = '". $currency . "' and status <> 'deleted';";

            echo $up . "<br />\n";
            mysql_query($up)or die(mysql_error());
        }   

        $strSQL2 = "select * from margins where rate_c_code = '". $currency ."' and status <> 'deleted';";
        $result2 = mysql_query($strSQL2);

        if( mysql_num_rows( $result2 ) == 0 ){

            $ins2 = "INSERT INTO margins SET ";
            $ins2 .= " rate_c_code = '" . $currency . "';";
            mysql_query( $ins2 ) or die( mysql_error() );
        } 

        return $currency . ':' . $rate;

    }

    $url[] = "http://www.xe.com/currency/usd-us-dollar";
    $url[] = "http://www.xe.com/currency/aud-australian-dollar";
    $url[] = "http://www.xe.com/currency/eur-euro";
    $url[] = "http://www.xe.com/currency/cad-canadian-dollar";
    $url[] = "http://www.xe.com/currency/czk-czech-koruna";
    $url[] = "http://www.xe.com/currency/dkk-danish-krone";
    $url[] = "http://www.xe.com/currency/hkd-hong-kong-dollar";
    $url[] = "http://www.xe.com/currency/nzd-new-zealand-dollar";
    $url[] = "http://www.xe.com/currency/jpy-japanese-yen";
    $url[] = "http://www.xe.com/currency/nok-norwegian-krone";
    $url[] = "http://www.xe.com/currency/zar-south-african-rand";
    $url[] = "http://www.xe.com/currency/sek-swedish-krona";
    $url[] = "http://www.xe.com/currency/chf-swiss-franc";
    $url[] = "http://www.xe.com/currency/try-turkish-lira";
    $url[] = "http://www.xe.com/currency/thb-thai-baht";
    $url[] = "http://www.xe.com/currency/aed-emirati-dirham";
    $url[] = "http://www.xe.com/currency/cny-chinese-yuan-renminbi";
    $url[] = "http://www.xe.com/currency/bgn-bulgarian-lev";
    $url[] = "http://www.xe.com/currency/brl-brazilian-real";
    $url[] = "http://www.xe.com/currency/egp-egyptian-pound";
    $url[] = "http://www.xe.com/currency/huf-hungarian-forint";
    $url[] = "http://www.xe.com/currency/hrk-croatian-kuna";
    $url[] = "http://www.xe.com/currency/lvl-latvian-lat";
    $url[] = "http://www.xe.com/currency/ltl-lithuanian-litas";
    $url[] = "http://www.xe.com/currency/mxn-mexican-peso";
    $url[] = "http://www.xe.com/currency/pln-polish-zloty";
    $url[] = "http://www.xe.com/currency/rub-russian-ruble";
    $url[] = "http://www.xe.com/currency/sgd-singapore-dollar";
    $url[] = "http://www.xe.com/currency/ttd-trinidadian-dollar";
    $url[] = "http://www.xe.com/currency/krw-south-korean-won";
    $url[] = "http://www.xe.com/currency/xcd-east-caribbean-dollar";
    $url[] = "http://www.xe.com/currency/xcd-east-caribbean-dollar";
    $url[] = "http://www.xe.com/currency/vnd-vietnamese-dong";
    $url[] = "http://www.xe.com/currency/myr-malaysian-ringgit";
    $url[] = "http://www.xe.com/currency/jmd-jamaican-dollar";
    $url[] = "http://www.xe.com/currency/ars-argentine-peso";
    $url[] = "http://www.xe.com/currency/bbd-barbadian-or-bajan-dollar";


    /* New Currencies added on 31-07-2012 */

    $url[] = "http://www.xe.com/currency/bhd-bahraini-dinar";
    $url[] = "http://www.xe.com/currency/ils-israeli-shekel";
    $url[] = "http://www.xe.com/currency/isk-icelandic-krona";
    $url[] = "http://www.xe.com/currency/jod-jordanian-dinar";
    $url[] = "http://www.xe.com/currency/clp-chilean-peso";
    $url[] = "http://www.xe.com/currency/dop-dominican-peso";
    $url[] = "http://www.xe.com/currency/idr-indonesian-rupiah";
    $url[] = "http://www.xe.com/currency/kes-kenyan-shilling";
    $url[] = "http://www.xe.com/currency/kwd-kuwaiti-dinar";
    $url[] = "http://www.xe.com/currency/lkr-sri-lankan-rupee";
    $url[] = "http://www.xe.com/currency/mur-mauritian-rupee";
    $url[] = "http://www.xe.com/currency/omr-omani-rial";
    $url[] = "http://www.xe.com/currency/pen-peruvian-nuevo-sol";
    $url[] = "http://www.xe.com/currency/php-philippine-peso";
    $url[] = "http://www.xe.com/currency/qar-qatari-riyal";
    $url[] = "http://www.xe.com/currency/ron-romanian-new-leu";
    $url[] = "http://www.xe.com/currency/sar-saudi-arabian-riyal";
    $url[] = "http://www.xe.com/currency/twd-taiwan-new-dollar";
    $url[] = "http://www.xe.com/currency/uah-ukrainian-hryvna";

    /** ADDED 2014-30-01 **/
    $url[] = "http://www.xe.com/currency/inr-indian-rupee";
    $url[] = "http://www.xe.com/currency/mad-moroccan-dirham";
    $url[] = "http://www.xe.com/currency/kyd-caymanian-dollar";
    $url[] = "http://www.xe.com/currency/fjd-fijian-dollar";
    $url[] = "http://www.xe.com/currency/cop-colombian-peso";
    $url[] = "http://www.xe.com/currency/bwp-botswana-pula";
    $url[] = "http://www.xe.com/currency/bmd-bermudian-dollar";
    $url[] = "http://www.xe.com/currency/bdt-bangladeshi-taka";

    echo '<header>
            <a href="rates" class="btn btn-primary pull-right">View Rates</a>
            <h2><span class="glyphicon glyphicon-align-justify"></span> Get Rates Result</h2>
          </header>
          <hr />';

    $ret = '';
    foreach($url as $newUrl) {    
        $ret .= getratefrom($newUrl) . '<br /><hr />';
    }