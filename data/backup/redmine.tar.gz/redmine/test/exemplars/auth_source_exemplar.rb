class AuthSource < ActiveRecord::Base
  generator_for :name, :start => 'Auth0'

end
