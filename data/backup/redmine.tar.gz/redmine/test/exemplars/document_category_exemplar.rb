class DocumentCategory < Enumeration
  generator_for :name, :start => 'DocumentCategory0'
  generator_for :type => 'DocumentCategory'

end
