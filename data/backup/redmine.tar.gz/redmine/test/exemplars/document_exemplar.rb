class Document < ActiveRecord::Base
  generator_for :title, :start => 'Document001'

end
