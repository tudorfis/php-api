class IssuePriority < Enumeration
  generator_for :name, :start => 'IssuePriority0'
  generator_for :type => 'IssuePriority'

end
