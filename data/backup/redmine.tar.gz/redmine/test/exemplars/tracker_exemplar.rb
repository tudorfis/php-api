class Tracker < ActiveRecord::Base
  generator_for :name, :start => 'Tracker 0'

end
