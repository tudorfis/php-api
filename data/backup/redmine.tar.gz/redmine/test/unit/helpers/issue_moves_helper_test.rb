require File.expand_path('../../../test_helper', __FILE__)

class IssueMovesHelperTest < ActionView::TestCase
end
